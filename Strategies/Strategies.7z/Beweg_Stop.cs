﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
	[Description("Bewegungsstopp mit einstellbarem Volumen")]

    public class Beweg_Stop : UserStrategy
	{
        #region Variables
       
        private int _abstand = 2;
        private bool _automatisch = true;
        private bool _profitOnly = true;
        private int _verkauf_Vol = 100;
        private IOrder oStop;
        private double Stopp;
        private int Stueck;
        private double _profit = 50;
        private bool _sendMail = true;
        private string BStopp = "Bewegungs-Stopp";
        private bool _stopLimit = true;
        private int delta = 0;
 
        #endregion

        protected override void Initialize()
		{
			CalculateOnBarClose = false;
            BarsRequired = 20;
            IsAutomated = _automatisch;
            Abstand = _abstand;
            Verkauf_Vol = _verkauf_Vol;

        }

        protected override void OnStartUp()
        {
           
            // Stopp-Order vorhanden??
            //if (ChartControl != null && _profitOnly) DrawTextFixed("MyText", "Bewegunsstopp für ca. " + _verkauf_Vol.ToString("F0") + " Stück ProfitOnly " + _profit , TextPosition.BottomLeft, Color.Red, new Font("Areal", 14), Color.Blue, Color.Empty, 10);
            //if (ChartControl != null && !_profitOnly) DrawTextFixed("MyText", "Bewegunsstopp für ca. " + _verkauf_Vol.ToString("F0") + " Stück ", TextPosition.BottomLeft, Color.Red, new Font("Areal", 14), Color.Blue, Color.Empty, 10);


            if (Trade != null && Trade.Quantity != 0)
            {
                if(Core.PreferenceManager.IsAtrEntryDistance) _abstand = (int)Math.Max(_abstand, ATR(14)[1] * Core.PreferenceManager.AtrEntryDistanceFactor);
                if (Orders.Count > 0)
                {
                    int i = 0;
                    do
                    {
                        if (Orders[i].Action == OrderAction.Sell && (Orders[i].OrderType == OrderType.Stop|| Orders[i].OrderType == OrderType.StopLimit))
                        {
                            oStop = Orders[i];
                            if (oStop.OrderState != OrderState.Filled)
                                Stopp = Orders[i].StopPrice + _abstand * TickSize;
                        }
                        ++i;
                    } while (i < Orders.Count);
                }
            }
        }
 

        protected override void OnExecution(IExecution execution)
        {

            if (execution.Order != null && execution.Order.OrderState == OrderState.Filled)
            {
                if (oStop != null && execution.Name == oStop.Name)
                {
                    // if (_sendMail && Core.PreferenceManager.DefaultEmailAddress != "") this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                    if (_sendMail) this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt.",
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt. Profit:" + (Trade.ClosedProfitLoss - execution.Commission).ToString("F2"));
                
                }
            }
        }
		protected override void OnBarUpdate()
		{
            if (Trade.Quantity * Trade.AvgPrice < 8000)
            {
                Stueck = Trade.Quantity;
            }
            else if (Trade.Quantity * Trade.AvgPrice < 12000)
            {
                Stueck = (int)(Trade.Quantity/2);
            }
            else //if (Trade.Quantity * Trade.AvgPrice >= 12000)
            {
                _verkauf_Vol = Math.Min((int)(Trade.Quantity), _verkauf_Vol); // Max Stueck <= Trade.Quantity
                _verkauf_Vol = Math.Max((int)(4000/Trade.AvgPrice), _verkauf_Vol);
                _verkauf_Vol = Math.Max((int)(Trade.Quantity - _verkauf_Vol), (int)(4000 / Trade.AvgPrice));   // < Restmenge muß über 4.000 Eur liegen
                Stueck = _verkauf_Vol;
            }
            if (oStop != null && oStop.OrderState == OrderState.Filled)
            {
                DrawTextFixed("MyText", " Bewegunsstopp ausgeführt ", TextPosition.BottomLeft, Color.Red, new Font("Areal", 14), Color.Blue, Color.Empty, 10);
                return;
            }

            if (ChartControl != null && _profitOnly) DrawTextFixed("MyText", "Bewegunsstopp für " + Stueck.ToString("F0") + " Stück ProfitOnly " + _profit + " € ", TextPosition.BottomLeft, Color.Red, new Font("Areal", 14), Color.Blue, Color.Empty, 10);
            if (ChartControl != null && !_profitOnly) DrawTextFixed("MyText", "Bewegunsstopp für "+ Stueck.ToString("F0") + " Stück ", TextPosition.BottomLeft, Color.Red, new Font("Areal", 14), Color.Blue, Color.Empty, 10);

            if (Trade == null || (Trade != null && (Trade.MarketPosition == PositionType.Flat) || Trade.Quantity < _verkauf_Vol))
            {
                if (oStop != null)
                { 
                    oStop.CancelOrder();
                }
                return;
            }

            if (!FirstTickOfBar) return;

            
                if (IsCurrentBarLast)
                {

                    if (Core.PreferenceManager.IsAtrEntryDistance) _abstand = (int)Math.Max(_abstand, ATR(14)[1] * Core.PreferenceManager.AtrEntryDistanceFactor);    // Tick-Abstand
                
                delta = (int)(Close[1] / 10 +1);

                    // Stopp-Berechnung: bei InsideBar zurück auf Aussenstab, sonst BarByBar
                if (InsideBarsMT().IsInsideBar[1] > 0)
                    {
                        Stopp = InsideBarsMT().LowBeforeOutsideBar[1];
                    }
                    else Stopp = Instrument.Round2TickSize(Math.Max(Stopp, Low[1]));


                    if (!_profitOnly || ((Stopp - _abstand * TickSize - Position.AvgPrice) * Stueck > _profit && _profitOnly))
                    {
                        if (oStop != null && oStop.OrderState != OrderState.Filled && oStop.OrderState != OrderState.PendingSubmit &&
                            oStop.OrderState != OrderState.PendingReplace && oStop.Price != Stopp - _abstand * TickSize)
                        {
                        if(_stopLimit)
                            ChangeOrder(oStop, Stueck, Stopp - (_abstand + delta) * TickSize, Stopp - _abstand * TickSize);
                        else
                            ChangeOrder(oStop, Stueck, Stopp - (_abstand + delta) * TickSize, Stopp - _abstand * TickSize);
                            //Print("1 Stop: " + oStop.Price + " Limit:" + oStop.LimitPrice);
                        }
                        else
                        {
                            if (oStop == null)
                            {
                                if(_stopLimit)
                                    oStop = SubmitOrder(0, OrderAction.Sell, OrderType.StopLimit, Stueck, Stopp - (_abstand + delta) * TickSize, Stopp - _abstand * TickSize, "Stopp B", BStopp);
                            else
                                    oStop = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, Stueck, 0, Stopp - _abstand * TickSize, "Stopp B", BStopp);
                                if (_automatisch) oStop.ConfirmOrder();
                           }
                        }
                    }
                
            }
            //if (FirstTickOfBar)
              //  Print(Instrument.Symbol + " Bar: " + CurrentBar + " Stueck: " + Stueck + " Stopp: " + Stopp + " offener G&V: " + Trade.OpenProfitLoss.ToString("F2"));
		}
        #region Properties
        
        [Description("Verkaufs-Menge")]
        [Category("Parameters")]
        public int Verkauf_Vol
        {
            get { return _verkauf_Vol; }
            set { _verkauf_Vol = value; }
        }
        

        [Description("nur Gewinn-Stopp")]
        [Category("Parameters")]
        public bool ProfitOnly
        {
            get { return _profitOnly; }
            set { _profitOnly = value; }
        }

        [Description("Profit")]
        [Category("Parameters")]
        public double Profit
        {
            get { return _profit; }
            set { _profit = Math.Max(0, value); }
        }

        [Description("Tick-Abstand")]
        [Category("Parameters")]
        public int Abstand
        {
            get { return _abstand; }
            set { _abstand = value; }
        }

        [Description("Stopp-Limit-Order")]
        [Category("Parameters")]
        public bool StopLimit
        {
            get { return _stopLimit; }
            set { _stopLimit = value; }
        }

        [Description("Automatisch")]
        [Category("Parameters")]
        public bool Automatisch
        {
            get { return _automatisch; }
            set { _automatisch = value; }
        }


        [Description("SendMail")]
        [Category("Parameters")]

        public bool SendMail
        {
            get { return _sendMail; }
            set { _sendMail = value; }
        }
        #endregion
	}
}
