/* Stragegie Wendepunkt
TimeFrames 1h (Chart) und 1 Day
EMA 200 als Filter
Kaufe am unteren Wendepunkt 1 Day unter der unteren Schwelle auf Tagesbasis bei überdurchschnittlichem Volumesumen am Tag oder Vortag
Liegt die Position im Plus:
Setzte Stopp unter das letzte Low am oberen Wendepunkt des MFI oberhalb der oberen Schwelle
mit Teilverkauf auf Stundenbasis
Verkaufe den Rest wenn der MFI auf Tagesbasis den Wendepunkt über der oberen Schwelle erreicht hat.

Anpassung für Test: Hour / 5 Min gegen Hour / Day und Profit
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
	[Description("Kaufe am unteren Wendepunkt auf Tagesbasis und ziehe den Stop unteer das Low am oberen Wendepunkt")]
	//[TimeFrameRequirements(("1 Hour"),("1 Day"))] // test mit 5 Min / 1 Hour / Day
    [TimeFrameRequirements(("5 Minute"), ("1 Hour"))]
    public class MFI_Strategie : UserStrategy
	{
		#region Variables

		private int _kapital = 9000;
        private int Stueck = 0;
        private int TeilStueck = 0;
        private double Stopkurs = 0;
        private int _trend = 3;
		private int _periode = 14;
		private int _teilverkauf = 50;
		private int _oschwelle = 70;
		private int _uschwelle = 30;
        private double VolFaktor = 1.1; // Volumenfaktor
        private double Profit = 100;
		private bool EntrySignalTag = false;
		private bool ExitSignalTag = false;
		private bool EntrySignalh = false;
		private bool ExitSignalh = false;
        private int Status = 0;
        private double EnterTag = 0;
        private double LineBar = 0;
    //    private static readonly TimeFrame TF1 = new TimeFrame(DatafeedHistoryPeriodicity.Hour, 1); // Zeiteinheit anpassen Hour / Day
    //    private static readonly TimeFrame TF2 = new TimeFrame(DatafeedHistoryPeriodicity.Day, 1); // Zeiteinheit anpassen Hour / Day
        private IOrder oEntry = null;
        private IOrder oStopp = null;
        private IOrder oStopp1 = null;

        #endregion

           
        protected override void OnStartUp()
        {
            if (ChartControl != null && BarsInProgress == 0)
            {
             DrawTextFixed("MyText", "MFI-Strategie " + TimeFrames[0] + " / " + TimeFrames[1], TextPosition.BottomLeft, Color.Red, new Font("Areal", 16), Color.Blue, Color.Empty, 10);
            }
        }

		protected override void Initialize()
		{
			CalculateOnBarClose = true;
            IsAutomated = true;
            BarsRequired = 200;
            TimeInForce = TimeInForce.Gtc;
        }

        protected override void OnBrokerConnect()

        {
            if (Trade != null && Trade.MarketPosition != PositionType.Flat)
            {
                Status = 3;
                Print("On Brokerconnect: bereits eine Position offen");
            }
            Print("Broker-Connect");
        }



        protected override void OnExecution(IExecution execution)
        {
            if(execution != null && execution.Order.OrderState == OrderState.Filled)
            { 
                if (oEntry != null && execution.Name == oEntry.Name)
                    { 
                        Status = 3;
                        Print(execution.Instrument + " Einstieg-Order: " + execution.Name + " Orderstatus: " + execution.Order.OrderState);
                    //Alert( " Entry Long", true, "OrderFilled.wav");
                }
                if (oStopp != null && execution.Name == oStopp.Name)
                    {
                        Status = 5;
                        Print(execution.Instrument + execution.Name + " Orderstatus: " + execution.Order.OrderState);
                        //Alert(Instrument.Symbol + " Orderänderung", true, "Stop-order-filled.wav");
                    }
                if (execution.Order.Action == OrderAction.Buy && execution.Name != "MFI")
                {
                    Status = 3;
                    Print(execution.Instrument + " Sonderfall, manuelle Order");
                }
                if (oStopp1 != null && execution.Name == oStopp1.Name)
                    {
                        Status = 0;
                        Print(execution.Instrument + " Target 2: " + execution.Name + " Orderstatus: " + execution.Order.OrderState);
                        //Alert(Instrument.Symbol + " Orderänderung", true, "Stop-order-filled.wav");
                    }
                //Print("Status:" + Status);
            }
        }

        protected override void OnBarUpdate()
		{
            // if (Status == -1) return; // Abbruch wenn keine Brokerbervindung besteht
            if (Status == 0 && Trade != null && Trade.MarketPosition != PositionType.Flat) Status = 3; // Es ist bereits eine Position offen
            if (BarsInProgress == 1 && IsCurrentBarLast)
            {
                switch (Status)
                {
                    case 0:
                       EntrySignalTag = ((MFI(Closes[1], _periode)[1] < MFI(Closes[1], _periode)[0]) &&
                                          (MFI(Closes[1], _periode)[1] < MFI(Closes[1], _periode)[2]) &&
                                          (MFI(Closes[1], _periode)[1] < _uschwelle)
                                          && Lows[1][1] < Lows[1][2] &&
                                         ((Volumes[1][0] * VolFaktor > SMA(Volumes[1], _periode)[0]) ||
                                          (Volumes[1][1] * VolFaktor > SMA(Volumes[1], _periode)[1])) &&
                                           Closes[1][0] > SMA(Closes[1], 200)[0]);  // Close über SMA 200
                                           

                        if (EntrySignalTag) Status = 1;
                        EnterTag = Math.Min(Highs[1][1], Highs[1][0]);
                       // if(Status == 1) Print("7 EntrySignalTag " + EntrySignalTag + " Status: " + Status + " Kaufkurs: " + EnterTag) ;
                        break;
                    case 5:
                        ExitSignalTag = (MFI(Closes[1], _periode)[1] > MFI(Closes[1], _periode)[0] && MFI(Closes[1], _periode)[1] > MFI(Closes[1], _periode)[2] &&
                                                 MFI(Closes[1], _periode)[1] > oSchwelle);
                        if (ExitSignalTag && (Lows[1][0] - Trade.AvgPrice) * Position.Quantity > Profit)
                        {
                           // Print("5");
                            Status = 6;
                            Stopkurs = Lows[1][0];
                        }
                       // Print("5a");
                        break;
                    case 6:
                        if ((Lows[1][0] - Trade.AvgPrice) * Position.Quantity > Profit)
                        {
                            //Print("6");
                            // Position schließen
                            Stopkurs = Math.Max(Stopkurs, Lows[1][1]);
                           // Print(Instrument.Symbol + " ExitSignal Tag, Verkauf Rest: " + Position.Quantity + "Profit: " + (Lows[1][0] - Trade.AvgPrice) * Position.Quantity);
                            if (oStopp1 != null)
                            {
                                ChangeOrder(oStopp1, Position.Quantity, 0, Stopkurs);
                            }
                            else
                            {
                                oStopp1 = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, Position.Quantity, 0, Stopkurs, "MFI", "Target 2");
                                oStopp1.ConfirmOrder();
                            }
                        }
                        break;
                    default: break;
                }
            }
                // alles im Zeitrahmen 0
            if (BarsInProgress == 0 && IsCurrentBarLast)
            {
                //Print("1");
                ExitSignalh = ((MFI(_periode)[1] > MFI(_periode)[2]) &&
                               (MFI(_periode)[1] > MFI(_periode)[0]) &&
                               (MFI(_periode)[1] > _oschwelle));
                //Print("2");
                DrawTextFixed("MyText", "MFI-Strategie " + TimeFrames[0] + " / " + TimeFrames[1], TextPosition.BottomLeft, Color.Red, new Font("Areal", 16), Color.Blue, Color.Empty, 10);
                
                if (Status == 0 && Trade != null && Trade.MarketPosition != PositionType.Flat) Status = 3;
                
               // Print(Instrument.Symbol + " Bar; " + CurrentBar + " Status: " + Status + " EnterTag: " + EntrySignalTag + " Exit-Signal h " + ExitSignalh + " ExitSignalTag: " + ExitSignalTag);

                switch (Status)
             {
                    case 0:
                        //Print("C00");
                        break;
                    case 1:
                        if (Account.CashValue > _kapital)
                        {
                           //Print("4");
                           Stopkurs = EnterTag;
                           Status = 2;
                        }
                        break;

                    case 2:
                        // OrderLong in den Markt
                        Stueck = (int)(_kapital / EnterTag);
                        //Print("C2");
                        Stopkurs = Instrument.Round2TickSize(Math.Min(Stopkurs, Highs[0][0]));
                        if (oEntry != null)
                            {
                            ChangeOrder(oEntry, Stueck, 0, Stopkurs);
                            }
                        else
                        {
                            oEntry = SubmitOrder(0, OrderAction.Buy, OrderType.Stop, Stueck, 0, Stopkurs, "MFI", "MFI");
                            if (IsAutomated) oEntry.ConfirmOrder();
                        }
                        break;

                    

                    case 3: // laufender Trade, bei ExitSignal und Position ist über Profit Teilverkauf
                        if (ExitSignalh && (Lows[0][1] - Trade.AvgPrice) * Position.Quantity > Profit) 
                        {
                            //Print("C3");
                            Status = 4;
                            Stopkurs = Low[1];
                            LineBar = CurrentBar;
                            DrawDot("Dot", true, 0, Stopkurs, Color.Blue);

                        }
                        break;
                   case 4:
                        if (GetCurrentPrice() > Lows[0][1] && (Lows[0][1] - Trade.AvgPrice) * Position.Quantity > Profit)
                        {
                            //Print("C4 " + CurrentBars[0]);
                            
                            Stopkurs = Instrument.Round2TickSize(Math.Max(Stopkurs, Low[1]));
                            //DrawDot("MyDot", true, 0, Stopkurs, Color.Blue);
                            DrawDot("MyDot", true, 0, Stopkurs, Color.Blue);
                            //DrawLine(string tag, bool autoScale, int startBarsAgo, double startY, int endBarsAgo, double endY, Color color, DashStyle dashStyle, int width)
                            //DrawLine("MyStop1", false, (CurrentBars[0] - LineBar), Low[LineBar], 0, Stopkurs, Color.Red, DashStyle.DashDotDot, 2);
                            DrawLine("MyStop1", false, 10, LineBar, 0, Stopkurs, Color.Red, DashStyle.DashDotDot, 2);
                            TeilStueck = (int)(Position.Quantity * _teilverkauf / 100);
                            if (Position.Quantity < Stueck) TeilStueck = Position.Quantity; // Teilmenge wurde schon verkauft
                            //Print(Instrument.Symbol + " Bar; " + CurrentBar + " Status: " + Status + " ExitSignalh: " + ExitSignalh + " ExitSignalTag: " + ExitSignalTag + "Verkauf: " + TeilStueck + " Stopp-Kurs: " + Stopkurs);
                            //Status = 6;
                            if (oStopp != null)
                            {
                                ChangeOrder(oStopp, TeilStueck, 0, Stopkurs);
                            }
                            else
                            {
                                 oStopp = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, TeilStueck, 0, Stopkurs, "MFI", "Target 1");
                                 oStopp.ConfirmOrder();
                            }
                        }
                        break;
                default: break;
                }
            }    
                
        }
         	

		#region Properties

		[Description("Kapitaleinsatz")]
		[Category("Parameters")]
		public int Kapital
		{
			get { return _kapital; }
			set { _kapital = Math.Max(4000, value); }
		}

		[Description("Trendstärke")]
		[Category("Parameters")]
		public int Trend
		{
			get { return _trend; }
			set { _trend = Math.Max(1, value); }
		}

		[Description("Perioden MFI")]
		[Category("Parameters")]
		public int Periode
		{
			get { return _periode; }
			set { _periode = Math.Max(1, value); }
		}

		[Description("Prozent Teilverkauf")]
		[Category("Parameters")]
		public int Teilverkauf
		{
			get { return _teilverkauf; }
			set { _teilverkauf = Math.Max(1, value); }
		}
		[Description("untere Schwelle MFI")]
		[Category("Parameters")]
		public int uSchwelle
		{
			get { return _uschwelle; }
			set { _uschwelle = Math.Min(50, value); }
		}
		[Description("obere Schwelle MFI")]
		[Category("Parameters")]
		public int oSchwelle
		{
			get { return _oschwelle; }
			set { _oschwelle = Math.Max(50, value); }
		}

		#endregion
	}
}
