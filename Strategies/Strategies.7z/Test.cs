using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
	[Description("Test BarbyBarStop")]
	public class Test : UserStrategy
	{
        #region Variables
        //      private int _trend = 2;
        private double Stopp = 0.0;
        private int _abstand = 2;
        private int _toleranz = 2;
        private bool HardStopp_aktiv = false;
        private int _profit = 2;
        private double Gewinn = 0.00;
     //   private StopBarByBar _StopBarByBar = null;
        private IOrder oStop = null;
        private bool _sendMail = true;
        private bool _softstopp = true;
        private bool _automatisch = true;
        private bool _profitOnly = true;
        private int _verkauf_Vol = 100;
        private int Stueck;
        private string BStopp = "Beweg.-Soft-Stopp";
        private bool _stopLimit = true;
        private int delta = 0;
        private IDataSeries SoftStopp = null;
        private IDataSeries HardStopp = null;
        private double H_Stopp = 0.00;

  

        #endregion Variables
        protected override void Initialize()
        {
            BarsRequired = 2;
            Abstand = _abstand;
            Toleranz = _toleranz;
            Automatisch = _automatisch;
            Softstopp = _softstopp;
            Profit = _profit;
            StopLimit = _stopLimit;

  
        }
        protected override void OnStartUp()
        {

            base.OnStartUp();
            // Parameter nach BarByBar schreiben
            //Init our indicator to get code access to the calculate method
         //   this._StopBarByBar = new StopBarByBar();
         // this.SoftStopp = this._StopBarByBar.SoftStopp;
           // this.HardStopp = this._StopBarByBar.HardStopp;



            if (Trade != null && Trade.Quantity != 0)
            {
                if (Core.PreferenceManager.IsAtrEntryDistance) _abstand = (int)Math.Max(_abstand, ATR(14)[1] * Core.PreferenceManager.AtrEntryDistanceFactor);
                if (Orders.Count > 0)
                {
                    int i = 0;
                    do
                    {
                        if (Orders[i].Action == OrderAction.Sell && (Orders[i].OrderType == OrderType.Stop || Orders[i].OrderType == OrderType.StopLimit))
                        {
                            oStop = Orders[i];
                            if (oStop.OrderState != OrderState.Filled)
                                Stopp = Orders[i].StopPrice + _abstand * TickSize;
                        }
                        ++i;
                    } while (i < Orders.Count);
                }
            }
        }


        protected override void OnExecution(IExecution execution)
        {

            if (execution.Order != null && execution.Order.OrderState == OrderState.Filled)
            {
                if (oStop != null && execution.Name == oStop.Name)
                {
                    if (_sendMail && Core.PreferenceManager.DefaultEmailAddress != "") this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgef�hrt.",
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgef�hrt. Profit:" + (Trade.ClosedProfitLoss - execution.Commission).ToString("F2"));

                }
            }
        }

        protected override void OnBarUpdate()
        {
            #region vorhandene Order einlesen
            if (Trade != null && Trade.Quantity != 0)
            {
                if (Orders.Count > 0)
                {
                    int i = 0;
                    do
                    {
                        if (Orders[i].Action == OrderAction.Sell && (Orders[i].OrderType == OrderType.Stop || Orders[i].OrderType == OrderType.StopLimit))
                        {
                            oStop = Orders[i];
                            //if (oStop.OrderState != OrderState.Filled)
                            //Stopp = Orders[i].StopPrice + _abstand * TickSize;
                        }
                        ++i;
                    } while (i < Orders.Count);
                }
            }
            #endregion vorhandene Order einlesen

            #region Stueck
            if (Trade == null)
            {
                DrawTextFixed("MyText", " kein Trade offen ", TextPosition.BottomLeft, Color.Red, new Font("Areal", 14), Color.Blue, Color.Empty, 10);
                return;
            }
            if (Trade.Quantity * Trade.AvgPrice < 8000)     // verkaufe alles
            {
                Stueck = Trade.Quantity;
            }
            else if (Trade.Quantity * Trade.AvgPrice < 12000)   // verkaufe alles oder die H�lfte
            {
                if (_verkauf_Vol <= (int)(Trade.Quantity / 2) + 1)
                    Stueck = (int)(Trade.Quantity / 2);
                else
                    Stueck = Trade.Quantity;
            }
            else if (_verkauf_Vol == Trade.Quantity)        // verkaufe alles oder ein Teilbetrag >= 4000
            {
                Stueck = Trade.Quantity;
            }

            else
            {
                _verkauf_Vol = Math.Min((int)(Trade.Quantity), _verkauf_Vol); // _verk-Vol <= Trade.Quantity
                _verkauf_Vol = Math.Max((int)((4000 / Trade.AvgPrice) + 1), _verkauf_Vol);
                //_verkauf_Vol = Math.Min((int)(Trade.Quantity - _verkauf_Vol), (int)(4000 / Trade.AvgPrice));   
                if ((Trade.Quantity - _verkauf_Vol) * Trade.AvgPrice < 4000)                 //  Restmenge mu� �ber 4.000 Eur liegen
                {
                    _verkauf_Vol = Trade.Quantity - (int)((4000 / Trade.AvgPrice) + 1);     // Restmenge = 4000
                }
                Stueck = _verkauf_Vol;
            }
            #endregion Stueck

            if (IsCurrentBarLast)
            {
                if (Core.PreferenceManager.IsAtrEntryDistance)
                    _abstand = (int)Math.Max(_abstand, ATR(14)[1] * Core.PreferenceManager.AtrEntryDistanceFactor);    // Tick-Abstand
                delta = (int)(Close[1] / 10 + 1);    // Differnenz Stopp-Limit-Preis, noc ohne Auswirkung

                #region Stopp_Berechnung
                // Stopp-Berechnung: bei InsideBar zur�ck auf Aussenstab, sonst BarByBar
                if (InsideBarsMT(Close, InsideBarsMTToleranceUnit.Ticks, _toleranz).IsInsideBar[0] > 0)
                {
                    Stopp = Instrument.Round2TickSize(InsideBarsMT(Close, InsideBarsMTToleranceUnit.Ticks, _toleranz).LowBeforeOutsideBar[0] - _abstand * TickSize);
                    // ggf oStop zur�cksetzen
                    if (oStop != null && oStop.StopPrice > Stopp && oStop.OrderState != OrderState.Filled &&
                        oStop.OrderState != OrderState.PartFilled && oStop.OrderState != OrderState.PendingSubmit &&
                        oStop.OrderState != OrderState.PendingReplace)
                    {
                        ChangeOrder(oStop, Stueck, Stopp - delta * TickSize, Stopp);
                        Print("Stop-Preis: " + oStop.Price + " Limit: " + oStop.LimitPrice);
                    }
                }
                else Stopp = Instrument.Round2TickSize(Math.Max(Stopp, (Low[1] - _abstand * TickSize)));
                if (_softstopp && oStop != null && Close[1] < Stopp - _abstand * TickSize)
                {
                    Stopp = Instrument.Round2TickSize(Math.Max(Low[1], Stopp) - _abstand * TickSize);
                }
                #endregion Stopp_Berechnung
                #region Hardstopp_Berechnung

                // 1 Hardstopp setzen
                if (oStop == null && (!_profitOnly || (_profitOnly && (Stopp > (Profit / Stueck + Trade.AvgPrice + _abstand * TickSize) * 1.0005))))
                {
                    if (_softstopp) Stopp = Instrument.Round2TickSize((Profit / Stueck) + Trade.AvgPrice);
                    if (_stopLimit)
                        oStop = SubmitOrder(0, OrderAction.Sell, OrderType.StopLimit, Stueck, Stopp - (_abstand + delta) * TickSize, Stopp - _abstand * TickSize, "Stopp B", BStopp);
                    else
                        oStop = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, Stueck, 0, Stopp - _abstand * TickSize, "Stopp B", BStopp);
                    if (_automatisch) oStop.ConfirmOrder();
                }
                // Hardstopp auf Low[1] nachsetzen und damit aktivieren
                if (oStop != null)
                {
                    if (Close[1] < (Stopp - _abstand * TickSize))
                    {
                        if (oStop.OrderState != OrderState.Filled && oStop.OrderState != OrderState.PartFilled && oStop.OrderState != OrderState.PendingSubmit &&
                            oStop.OrderState != OrderState.PendingReplace && oStop.Price != Stopp - _abstand * TickSize)
                        {
                            ChangeOrder(oStop, Stueck, Stopp - (_abstand + delta) * TickSize, Stopp - _abstand * TickSize);
                            Print("2 Stop: " + oStop.Price + " Limit:" + oStop.LimitPrice);
                        }
                    }
                }
                #endregion Hardstopp_Berechnung


            }
        }



        #region Properties

        [Description("Profit in Promille, 0 f�r kein Profit only")]
        [Category("Parameters")]
        public int Profit
        {
            get { return _profit; }
            set { _profit = Math.Max(0, value); }
        }

        [Description("Toleranz f�r InsideBars")]
        [Category("General")]
        public int Toleranz
        {
            get { return _toleranz; }
            set { _toleranz = value; }
        }

        [Description("Tick-Abstand vom Tief")]
        [Category("General")]
        public int Abstand
        {
            get { return _abstand; }
            set { _abstand = value; }
        }

        [Description("Soft-Stopp aktivieren")]
        [Category("Parameters")]
        public bool Softstopp
        {
            get { return _softstopp; }
            set { _softstopp = value; }
        }


        [Description("Stopp-Order als Stopp-Limit-Order")]
        [Category("Parameters")]
        public bool StopLimit
        {
            get { return _stopLimit; }
            set { _stopLimit = value; }
        }

        [Description("Automatische Aktivierung der Stopp-Order")]
        [Category("Parameters")]
        public bool Automatisch
        {
            get { return _automatisch; }
            set { _automatisch = value; }
        }


        [Description("Versenden eine E-Mail nach Ausf�hrung")]
        [Category("Parameters")]

        public bool SendMail
        {
            get { return _sendMail; }
            set { _sendMail = value; }
        }
    }
    #endregion Properties
}
