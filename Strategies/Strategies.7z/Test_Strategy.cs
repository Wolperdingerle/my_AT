using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

/// <summary>
/// Version: 1.2.2
/// -------------------------------------------------------------------------
/// Simon Pucher 2016
/// Christian Kovar 2016
/// -------------------------------------------------------------------------
/// This strategy provides provides entry and exit signals for a SMA crossover.
/// Long  Signal when fast SMA crosses slow SMA above. Plot is set to  1.
/// Short Signal wenn fast SMA crosses slow SMA below. Plot is set to -1.
/// StopLoss is set to 1% and Target is set to 3%
/// You can use this indicator also as a template for further script development.
/// -------------------------------------------------------------------------
/// Namespace holds all indicators and is required. Do not change it.
/// </summary>
namespace AgenaTrader.UserCode
{
    [Description("Test_Strategie")]
    // public class Example_Strategy_SMA_CrossOver_Advanced1 : UserStrategy
    public class Test_Strategy : UserStrategy
    {

        //input
        private bool _autopilot = true;
        private bool _IsLongEnabled = true;
        private bool _IsShortEnabled = true;
  //      private int _fastsma = 20;
  //      private int _slowsma = 50;
        private int _abstand = 3;
        private int _toleranz = 2;
        private int _barsRequired = 2;

        //output

        //internal
        //internal
        //private StopBarByBar _StopBarByBar = null;
        private Test_Indikator _Test_Indikator = null;
        private IOrder _orderenterlong;
        private IOrder _orderentershort;

		protected override void Initialize()
		{
            CalculateOnBarClose = true;

            //Set the default time frame if you start the strategy via the strategy-escort
            //if you start the strategy on a chart the TimeFrame is automatically set, this will lead to a better usability
            if (this.TimeFrame == null || this.TimeFrame.PeriodicityValue == 0)
            {
                this.TimeFrame = new TimeFrame(DatafeedHistoryPeriodicity.Hour, 1);
            }
            this.BarsRequired = _barsRequired;
        }


        protected override void OnStartUp()
        {
            base.OnStartUp();
            //Init our indicator to get code access to the calculate method
            this._Test_Indikator = new Test_Indikator();
            //this._StopBarByBar.Abstand = _abstand;
           // this._StopBarByBar.Toleranz = _toleranz;

        }

		protected override void OnBarUpdate()
		{
            //Set Autopilot
            this.IsAutomated = this.Autopilot;

            //Check if peridocity is valid for this script
            if (!this._Test_Indikator.DatafeedPeriodicityIsValid(Bars.TimeFrame))
            {
                Log(this.DisplayName + ": Periodicity of your data feed is suboptimal for this indicator!", InfoLogLevel.AlertLog);
                return;
            }

            //Lets call the calculate method and save the result with the trade action
            // ResultValue_StopBarByBar returnvalue = this._StopBarByBar.calculate(this.Input, this.FastSma, this.SlowSma, this.IsLongEnabled, this.IsShortEnabled);
            ResultValue_Test_Indikator returnvalue = this._Test_Indikator.calculate(this.Input, this._abstand, this._toleranz, this.IsLongEnabled, this.IsShortEnabled);
            //If the calculate method was not finished we need to stop and show an alert message to the user.
            if (returnvalue.ErrorOccured)
            {
                Log(this.DisplayName + ": A problem has occured during the calculation method!", InfoLogLevel.AlertLog);
                return;
            }

            //Entry
            if (returnvalue.Entry.HasValue)
            {
                switch (returnvalue.Entry)
                {
                    case OrderAction.Buy:
                        this.DoEnterLong();
                        break;
                    case OrderAction.SellShort:
                        this.DoEnterShort();
                        break;
                }
            }

            //Exit
            if (returnvalue.Exit.HasValue)
            {
                switch (returnvalue.Exit)
                {
                    case OrderAction.BuyToCover:
                        this.DoExitShort();
                        break;
                    case OrderAction.Sell:
                        this.DoExitLong();
                        break;
                }
            }
		}


        /// <summary>
        /// Create LONG order.
        /// </summary>
        private void DoEnterLong()
        {
            if (_orderenterlong == null)
            {
                _orderenterlong = EnterLong(this.DefaultQuantity, this.DisplayName + "_" + OrderAction.Buy + "_" + this.Instrument.Symbol + "_" + Bars[0].Time.Ticks.ToString(), this.Instrument, this.TimeFrame);
                
                //set a stop loss for our order. we set it 1% below the current price
                SetStopLoss(_orderenterlong.Name, CalculationMode.Price, Bars[0].Close * 0.99, false);

                //set a target for our order. we set it 3% above the current price
                SetProfitTarget(_orderenterlong.Name, CalculationMode.Price, Bars[0].Close * 1.05);
            }
        }

        /// <summary>
        /// Create SHORT order.
        /// </summary>
        private void DoEnterShort()
        {
            if (_orderentershort == null)
            {
                _orderentershort = EnterShort(this.DefaultQuantity, this.DisplayName + "_" + OrderAction.SellShort + "_" + this.Instrument.Symbol + "_" + Bars[0].Time.Ticks.ToString(), this.Instrument, this.TimeFrame);

                //set a stop loss for our order. we set it 1% above the current price
                SetStopLoss(_orderentershort.Name, CalculationMode.Price, Bars[0].Close * 1.01, false);

                //set a target for our order. we set it 3% below the current price
                SetProfitTarget(_orderentershort.Name, CalculationMode.Price, Bars[0].Close * 0.95);
            }
        }

        /// <summary>
        /// Exit the LONG position.
        /// </summary>
        private void DoExitLong()
        {
            if (_orderenterlong != null)
            {
                 ExitLong(this._orderenterlong.Name);
                 this._orderenterlong = null;
            }
        }

        /// <summary>
        /// Fill the SHORT position.
        /// </summary>
        private void DoExitShort()
        {
            if (_orderentershort != null)
            {
                ExitShort(this._orderentershort.Name);
                this._orderentershort = null;
            }
        }

        /// <summary>
        /// defines display name of indicator (e.g. in AgenaTrader chart window)
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return "Strategie_Test_Indikator (S)";
        }

        /// <summary>
        /// defines display name of indicator (e.g. in AgenaTrader indicator selection window)
        /// </summary>
        public override string DisplayName
        {
            get
            {
                return "Strategie_Test_Indikator (S)";
            }
        }


        #region Properties

        #region Parameter Indicator

        [Description("Abstand vom Perioden-Tief.")]
        [Category("General")]
        [DisplayName("Abstand")]
        public int Abstand
        {
            get { return _abstand; }
            set { _abstand = Math.Max(0, value); }
        }


        [Description("Toleranz f�r Inside-Bars.")]
        [Category("General")]
        [DisplayName("Toleranz")]
        public int Toleranz
        {
            get { return _toleranz; }
            set { _toleranz = Math.Max(0, value); }
        }

/*
        [Description("Mindestanzahl der Bars.")]
        [Category("General")]
        [DisplayName("Bars erforderlich")]
        public int BarsRequiered
        {
            get { return _barsRequired; }
            set { _toleranz = Math.Max(2, value); }
        }
        */
        #endregion

        #region Input
        /*
                /// <summary>
                /// </summary>
                [Description("The period of the fast SMA indicator.")]
                [Category("Parameters")]
                [DisplayName("Period fast")]
                public int FastSma
                {
                    get { return _fastsma; }
                    set { _fastsma = value; }
                }


                /// <summary>
                /// </summary>
                [Description("The period of the slow SMA indicator.")]
                [Category("Parameters")]
                [DisplayName("Period slow")]
                public int SlowSma
                {
                    get { return _slowsma; }
                    set { _slowsma = value; }
                }
        */
        [Description("Wenn auf true gesetzt, handelt das System vollautomatisch")]
        [Category("Safety first!")]
        [DisplayName("Autopilot")]
        public bool Autopilot
        {
            get { return _autopilot; }
            set { _autopilot = value; }
        }

        /// <summary>
        /// </summary>
        [Description("If true it is allowed to create long positions.")]
        [Category("Parameters")]
        [DisplayName("Allow Long")]
        public bool IsLongEnabled
        {
            get { return _IsLongEnabled; }
            set { _IsLongEnabled = value; }
        }


        /// <summary>
        /// </summary>
        [Description("If true it is allowed to create short positions.")]
        [Category("Parameters")]
        [DisplayName("Allow Short")]
        public bool IsShortEnabled
        {
            get { return _IsShortEnabled; }
            set { _IsShortEnabled = value; }
        }




        #endregion

        #endregion

    }
}
