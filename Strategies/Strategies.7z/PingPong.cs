﻿
/* PingPong
Handel der halben Position als Bewegung,
die andere Hälfte folgt dem Trend.
Nachkauf der Hälfte
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
    // Strategie PingPong kauft 5.000 in der Korrektur und Verkauft in der Bewegung mit MT BarMover-Stop
    // Rückkauf für 5.000 in der Korrektur, solange Trend in Trendgröße 1 > 0 ist und der Rücklauf bis zu P2 reicht
    // die 2. Hälfte folgt P2-Stop
	[Description("PingPong Verkauf in der Bewegung und kaufe in der Korrektur, jeweils mit5.000 €")]
	public class PingPong : UserStrategy
	{
	#region Variables
        private int _kapital = 5000;
        private double Wert = 0;
        private int _trend = 2;
        private int _abstand = 2;
        private int _delta = 5;
        private bool _automatisch = true;
        private bool _profitOnly = true;
        private int _profit = 50;
        private IOrder oEnterOrder = null;
        private string EnterName = "PingPong";
        private double EStopPreis = 0;
        private double StopPreis = 0;
        private double BStopPreis = 0;
        private double TStopPreis = 0;
        // private int quantity = 0;
        private IOrder oBewegungStopOrder = null;
        private string Beweg_Stopp = "Bewegung-Stopp";
        private IOrder oTrendStopOrder = null;
        private string Trend_Stopp = "Trend-Stopp";
        private IOrder oBuyOrder  = null;
        private string BuyName = "Korrektur-Kauf";
        private int OrderStatus = 0;
        private bool EnterSignal = false;
        private bool _stopLimit = false; // Stop-Order oder Stop-Limit-Order
        private double P1;
        private double P2;
        private double P3;
        private int Stueck;
        private bool _sendMail = true;
        private int _barBack = 2;        // BarBack = 1 = letzter Bar, Bar[0] = laufender bar, nicht abgeschlossen
        private int LastTrade = 0;      // letzter Trade -1 = Bewegung Verkauf, +1 Nachkauf/Kauf

        #endregion

        protected override void Initialize()
		{
            
            BarsRequired = 1000;
            IsAutomated = _automatisch;
            CalculateOnBarClose = false;
            BarBack = _barBack;
            Profit = _profit;
            ProfitOnly = _profitOnly;
            Delta = _delta;
            StopLimit = _stopLimit;
        }

    
        protected override void OnExecution(IExecution execution)
        {

            if (execution.Order != null && execution.Order.OrderState == OrderState.Filled)
            {
                if (oEnterOrder != null && execution.Name == oEnterOrder.Name)
                {
                    if (_sendMail && Core.PreferenceManager.DefaultEmailAddress != "") this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt.",
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt. Stück:" + execution.Quantity);
                    LastTrade = 1;
                }
                else if (oBewegungStopOrder != null && execution.Name == oBewegungStopOrder.Name)
                {
                    if (_sendMail && Core.PreferenceManager.DefaultEmailAddress != "") this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                        execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt.",
                        execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt. Profit:" + (Trade.ClosedProfitLoss - execution.Commission).ToString("F2"));
                    LastTrade = -1;

                }
                else if (oTrendStopOrder != null && execution.Name == oTrendStopOrder.Name)
                {
                    if (_sendMail && Core.PreferenceManager.DefaultEmailAddress != "") this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                        execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt.",
                        execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt. Profit:" + (Trade.ClosedProfitLoss - execution.Commission).ToString("F2"));
                }

                else if (oBuyOrder != null && execution.Name == oBuyOrder.Name)
                {
                    if (_sendMail && Core.PreferenceManager.DefaultEmailAddress != "") this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt.",
                         execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt. Stück:" + execution.Quantity);
                    LastTrade = 1;
                }
                else // sonstige Order

                {
                    if (_sendMail && Core.PreferenceManager.DefaultEmailAddress != "") this.SendEmail(Core.AccountManager.Core.Settings.MailDefaultFromAddress, Core.PreferenceManager.DefaultEmailAddress,
                        execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt.",
                        execution.Instrument.Symbol + " Order " + execution.Name + " ausgeführt. Profit:" + (Trade.ClosedProfitLoss - execution.Commission).ToString("F2"));

                }
            }
           // Print(execution.Name + " Orderänderung: " + " Orderstatus: " + execution.Order.OrderState + " Status: " + OrderStatus);
        }



        protected override void OnStartUp()
        {
            if (ChartControl != null)
            {
               // if (_automatisch) DrawTextFixed("MyText", "automatischer Handel Ping-Pong im Trend " + _trend.ToString(), TextPosition.BottomLeft, Color.Red, new Font("Areal", 18), Color.Blue, Color.Empty, 10);
               // else DrawTextFixed("MyText", "manueller Handel Handel Ping-Pong im Trend " + _trend.ToString(), TextPosition.BottomLeft, Color.Red, new Font("Areal", 18), Color.Blue, Color.Empty, 10);
            }
            if (Orders.Count > 0)   // suche nach vorhandenen Orders
            {
                int i = 0;
                do
                {
                    if((Trade == null && Orders[i].Action == OrderAction.Buy) || Orders[i].Name == EnterName)
                    { 
                        oEnterOrder = Orders[i];        // Einstiegs- (Start)- Order
                    }
                    else if (Orders[i].Name == BuyName)   //Orders[i].Action == OrderAction.Buy && Orders[i].OrderState != OrderState.Filled && Orders[i].OrderType == OrderType.Stop)
                        oBuyOrder = Orders[i];      // Nachkauf-Order
                    else if (Orders[i].Name == Beweg_Stopp) // Orders[i].Action == OrderAction.Sell && Orders[i].OrderState != OrderState.Filled && Orders[i].OrderType == OrderType.Stop && Orders[i].Name == Beweg_Stopp)
                        oBewegungStopOrder = Orders[i];      // Bewegungs-Stop-Order
                    else if (Orders[i].Name == Trend_Stopp)      //Orders[i].Action == OrderAction.Sell && Orders[i].OrderState != OrderState.Filled && Orders[i].OrderType == OrderType.Stop && Orders[i].Name == Trend_Stopp)
                        oTrendStopOrder = Orders[i];      // Bewegungs-Stop-Order
                    else
                        Print(Instrument.Symbol + " sonstige Order vorhanden: " + Orders[i].Name);
                    ++i;
                } while (i < Orders.Count);
            }
        }


		protected override void OnBarUpdate()
		{
            
            if (FirstTickOfBar)
            {
                if (Core.PreferenceManager.IsAtrEntryDistance)
                    _abstand = (int)Math.Max(_abstand, ATR(14)[1] * Core.PreferenceManager.AtrEntryDistanceFactor);     // Tick-Abstand
                P1 = P123Adv(Trend).P1Price[0];
                P2 = P123Adv(Trend).P2Price[0];
                if (P2 > P1 && P123Adv(Trend).P2DateTime[0] > P123Adv(Trend).P1DateTime[0])
                {
                    P3 = Math.Max(P123Adv(Trend).ValidP3Price[0], P123Adv(Trend).P1Price[0]); // Trend ok, Stopp auf P1  oder P3
                }
                else
                {
                    P3 = P123Adv(Trend).P2Price[0]; // bei Trendbruch Stopp an P2
                }
                
                /* if (oEnterOrder != null && oEnterOrder.OrderState == OrderState.Filled) oEnterOrder = null;
                 if (oBewegungStopOrder != null && oBewegungStopOrder.OrderState == OrderState.Filled) oBewegungStopOrder = null;
                 if (oTrendStopOrder != null && oTrendStopOrder.OrderState == OrderState.Filled) oTrendStopOrder = null;
                 if (oBuyOrder != null && oBuyOrder.OrderState == OrderState.Filled) oBuyOrder = null;
                 */
                if (Trade != null && LastTrade == 0 && oBuyOrder == null && oBewegungStopOrder == null)
                {
                    if (Trade.Quantity * Trade.AvgPrice < _kapital * 1.5 ) LastTrade = -1;  // Teilverkauf, Nachkauf aktivieren
                    if (Trade.Quantity * Trade.AvgPrice >= _kapital * 1.5 ) LastTrade = 1;  // Bewegungsstopp aktivieren
                }


                #region EnterOrder
                if (Trade == null || (Trade != null && Trade.MarketPosition == PositionType.Flat))
                {
                    if (Account.CashValue < 4 * _kapital)
                    {
                        if (oBuyOrder != null) oBuyOrder.CancelOrder();
                        if (oEnterOrder != null) oEnterOrder.CancelOrder();
                        //oBuyOrder = null;
                        //oEnterOrder = null;
                        return;   // Für Handel muß noch mindestens der doppelte Cash im Konto sein.
                    }
                    if (EStopPreis < 0.1)
                        EStopPreis = Instrument.Round2TickSize(HighestHighPrice(_barBack)[0] + _abstand * TickSize); // Stoppreis über das letzte Hoch    
                    else EStopPreis = Math.Min(EStopPreis, Instrument.Round2TickSize(HighestHighPrice(_barBack)[0] + _abstand * TickSize)); // Stoppreis über das letzte Hoch    
                    Stueck = 2 * (int)((_kapital / EStopPreis) + 1);
                    if (oEnterOrder == null )  // EnterOrder ist nicht vorhanden
                       {
                        EStopPreis = Math.Min(EStopPreis, Instrument.Round2TickSize(HighestHighPrice(_barBack)[0] + _abstand * TickSize)); // Stoppreis über das letzte Hoch    
                        if (_stopLimit)
                                oEnterOrder = SubmitOrder(0, OrderAction.Buy, OrderType.StopLimit, Stueck, EStopPreis + _delta * TickSize, EStopPreis, "", EnterName);
                            else
                                oEnterOrder = SubmitOrder(0, OrderAction.Buy, OrderType.Stop, Stueck, 0, EStopPreis, "", EnterName);
                       }
                        else
                        {
                          
                            if (oEnterOrder != null && oEnterOrder.OrderState != OrderState.Filled && oEnterOrder.StopPrice != EStopPreis && oEnterOrder.Quantity != Stueck &&
                                oEnterOrder.OrderState != OrderState.PendingReplace && oEnterOrder.OrderState != OrderState.PendingSubmit)
                            {
                                if (_stopLimit)
                                    ChangeOrder(oEnterOrder, Stueck, EStopPreis + _delta * TickSize, EStopPreis);
                                else
                                    ChangeOrder(oEnterOrder, Stueck, 0, EStopPreis);
                            }
                        }
                    
                }   // Ende Behandlung Enter-Order
                #endregion


                #region Bewegungs-Stopp
                if (LastTrade == 1 && Trade != null)
                {
                    
                    if (Trade.Quantity * Trade.AvgPrice < 8000)
                        Stueck = Trade.Quantity;                                // verkaufe alles
                    else if (Trade.Quantity * Trade.AvgPrice < 12000)
                        Stueck = (int)(Trade.Quantity / 2);                                // verkaufe die Hälfte
                    else
                        Stueck = Math.Min(Trade.Quantity, (int)(_kapital / High[0] + 1));
                    if (oBewegungStopOrder != null && oBewegungStopOrder.OrderState == OrderState.Filled) oBewegungStopOrder = null;
                    // Stopp-Berechnung: bei InsideBar zurück auf Aussenstab, sonst BarByBar
                    if (InsideBarsMT().IsInsideBar[1] > 0)
                        BStopPreis = InsideBarsMT().LowBeforeOutsideBar[1];
                    else
                        if(oBewegungStopOrder == null)
                            BStopPreis = Instrument.Round2TickSize(Low[1]);
                        else
                            BStopPreis = Instrument.Round2TickSize(Math.Max(oBewegungStopOrder.StopPrice, Low[1]));

                    if (!_profitOnly || ((BStopPreis - _abstand * TickSize - Position.AvgPrice) * Stueck > _profit && _profitOnly))
                    {
                        if(((BStopPreis - _abstand * TickSize - Position.AvgPrice) * Stueck < _profit && _profitOnly))  // Position liegt unter Profit
                        {
                            if(oBewegungStopOrder != null) oBewegungStopOrder.CancelOrder();
                        }
                        else
                        { 
                            if (oBewegungStopOrder != null && oBewegungStopOrder.OrderState != OrderState.Filled && oBewegungStopOrder.OrderState != OrderState.PendingSubmit &&
                                oBewegungStopOrder.OrderState != OrderState.PendingReplace && oBewegungStopOrder.StopPrice != BStopPreis - _abstand * TickSize)
                            {
                                if (_stopLimit)
                                    ChangeOrder(oBewegungStopOrder, Stueck, BStopPreis - (_abstand + _delta) * TickSize, BStopPreis - _abstand * TickSize);
                                else
                                    ChangeOrder(oBewegungStopOrder, Stueck, 0, BStopPreis - _abstand * TickSize);
                            }
                            else
                            {
                                if (oBewegungStopOrder == null)
                                {
                                    if (_stopLimit)
                                        oBewegungStopOrder = SubmitOrder(0, OrderAction.Sell, OrderType.StopLimit, Stueck, BStopPreis - (_abstand + _delta) * TickSize, BStopPreis - _abstand * TickSize, "Stopp B", Beweg_Stopp);
                                    else
                                        oBewegungStopOrder = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, Stueck, 0, BStopPreis - _abstand * TickSize, "Stopp B", Beweg_Stopp);
                                    if (_automatisch) oBewegungStopOrder.ConfirmOrder();
                                }
                            }
                        }
                        Print(Instrument.Symbol + " BewegungsOrder-Zeitstempel: " + oBewegungStopOrder.Time + " Stopp-Preis: " + BStopPreis);
                    }
                    
                }
                #endregion

                #region Trend-Stopp
                if (Trade != null && Trade.MarketPosition != PositionType.Flat)
                {
                    if (oBewegungStopOrder != null && oBewegungStopOrder.OrderState != OrderState.Filled && oBewegungStopOrder.OrderState != OrderState.PendingSubmit &&
                       oBewegungStopOrder.OrderState != OrderState.PendingReplace)
                        Stueck = Trade.Quantity - oBewegungStopOrder.Quantity;
                    else Stueck = Trade.Quantity;
                    TStopPreis = Instrument.Round2TickSize(P3);
                    if (Stueck < 1) return;
                    if (!_profitOnly || ((TStopPreis - _abstand * TickSize - Position.AvgPrice) * Stueck > _profit && _profitOnly))
                    {
                        if (((TStopPreis - _abstand * TickSize - Position.AvgPrice) * Stueck < _profit && _profitOnly))
                        {
                            if (oTrendStopOrder != null) oTrendStopOrder.CancelOrder(); 
                        }
                        else
                        { 
                            if (oTrendStopOrder != null && oTrendStopOrder.OrderState != OrderState.Filled && oTrendStopOrder.OrderState != OrderState.PendingSubmit &&
                                oTrendStopOrder.OrderState != OrderState.PendingReplace && oTrendStopOrder.StopPrice != TStopPreis - _abstand * TickSize)
                            {
                                ChangeOrder(oTrendStopOrder, Stueck, TStopPreis - (_abstand + _delta) * TickSize, TStopPreis - _abstand * TickSize);
                            }
                            else
                            {
                                if (oTrendStopOrder == null)
                                    {
                                    //oStop = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, Stueck, 0, TStopPreis - _abstand * TickSize, "Stopp B", BStopp);
                                    if (_stopLimit)
                                        oTrendStopOrder = SubmitOrder(0, OrderAction.Sell, OrderType.StopLimit, Stueck, TStopPreis - (_abstand + _delta) * TickSize, TStopPreis - _abstand * TickSize, "Stopp B", Trend_Stopp);
                                    else
                                    { 
                                        oTrendStopOrder = SubmitOrder(0, OrderAction.Sell, OrderType.Stop, Stueck, TStopPreis - (_abstand + _delta) * TickSize, TStopPreis - _abstand * TickSize, "Stopp B", Trend_Stopp);
                                        if (_automatisch) oTrendStopOrder.ConfirmOrder();
                                    }
                                }
                            }
                        }
                        Print(Instrument.Symbol + " " + Time[1] + " LastTrade: " + LastTrade + " T-Stopp: " + TStopPreis + " P3 :" + P3.ToString("F2"));
                    }
                }
                #endregion


                #region Nachkauf oBuyOrder
                // Nachkauf nur wenn High[1] unter Ausstiegspreis - Profit gesunken ist und Low[0] über P3 im Aufwärtstrend bzw P2 im abwärtstrend liegt
                if (LastTrade != 1 && Trade != null)
                {
                    if (Account.CashValue < 2 * _kapital)
                    {
                        if (oBuyOrder != null) oBuyOrder.CancelOrder();
                        //oBuyOrder = null;
                        return;   // Für Handel muß noch mindestens der doppelte Cash im Konto sein.
                    }
                    if (oBuyOrder != null && oBuyOrder.OrderState == OrderState.Filled) oBuyOrder = null;
                    if (oBewegungStopOrder != null && oBewegungStopOrder.OrderState == OrderState.Filled)
                    Stueck = oBewegungStopOrder.Quantity;
                else Stueck = (int)(_kapital / High[0] + 1);
                if (oBewegungStopOrder != null && oBewegungStopOrder.OrderState == OrderState.Filled &&
                    HighestHighPrice(_barBack)[0] < oBewegungStopOrder.AvgFillPrice - (_profit / Stueck) && LowestLowPrice(2)[0] > P3)
                {
                    if (oBuyOrder == null)
                    { 
                        StopPreis = Instrument.Round2TickSize(HighestHighPrice(_barBack)[0]);
                        if (_stopLimit)
                            oBuyOrder = SubmitOrder(0, OrderAction.Buy, OrderType.StopLimit, Stueck, StopPreis + (_abstand +_delta)* TickSize, StopPreis + _abstand * TickSize, "", BuyName);
                        else
                            oBuyOrder = SubmitOrder(0, OrderAction.Buy, OrderType.Stop, Stueck, 0, StopPreis + _abstand * TickSize, "", BuyName);
                        if (_automatisch) oBuyOrder.ConfirmOrder();
                    }
                    else
                    {
                        if(oBuyOrder.OrderState != OrderState.PendingReplace && oBuyOrder.OrderState != OrderState.Filled && oBuyOrder.OrderState != OrderState.PendingSubmit &&
                            oBuyOrder.OrderState != OrderState.PendingReplace && StopPreis - (Abstand + _delta) * TickSize != oBuyOrder.StopPrice)
                        { 
                            StopPreis = Instrument.Round2TickSize(Math.Min(oBuyOrder.StopPrice - Abstand * TickSize, HighestHighPrice(_barBack)[0]));
                            if (_stopLimit)
                                    ChangeOrder(oBuyOrder, Stueck, StopPreis + (Abstand + _delta) * TickSize, StopPreis + Abstand * TickSize);
                            else
                                    ChangeOrder(oBuyOrder, Stueck, 0, StopPreis + Abstand * TickSize);
                            }
                    }
                        Print(Instrument.Symbol + " " + Time[1] + " BuyOrder-Zeit: " + oBuyOrder.Time);
                    }
                }
                #endregion

                //if (Trade != null) Print("Closed Profit: " + Trade.ClosedProfitLoss + " open Profit: " + Trade.OpenProfitLoss + "  LastTrade: " + LastTrade);
                //Print("EnterSignal " + EnterSignal+ " OrderStatus: " + OrderStatus + " P1: " + P1 + " P2 " + P2 + " P3 " + P3 + " Stopp: " + Stopp);
               
            }

		}

		#region Properties

		[Description("eingesetztes Kapital")]
		[Category("Parameters")]
		public int Kapital
		{
			get { return _kapital; }
			set { _kapital = Math.Max(4000, value); }
		}

		[Description("Trendgröße")]
		[Category("Parameters")]
		public int Trend
		{
			get { return _trend; }
			set { _trend = Math.Max(1, value); }
		}

		[Description("Tickabstand")]
		[Category("Parameters")]
		public int Abstand
		{
			get { return _abstand; }
			set { _abstand = Math.Max(1, value); }
		}


        [Description("Abstand Stopp - LimitTickabstand in Ticks")]
        [Category("Parameters")]
        public int Delta
        {
            get { return _delta; }
            set { _delta = value; }
        }

        [Description("Bars back für Trailing Stop")]
        [Category("Parameters")]
        public int BarBack
        {
            get { return _barBack; }
            set { _barBack = Math.Max(1, value); }
        }


        [Description("nur Gewinn-Stopp")]
        [Category("Parameters")]
        public bool ProfitOnly
        {
            get { return _profitOnly; }
            set { _profitOnly = value; }
        }

        [Description("Profit")]
        [Category("Parameters")]
        public int Profit
        {
            get { return _profit; }
            set { _profit = Math.Max(0, value); }
        }


        [Description("Automatisch")]
		[Category("Strategy")]
		public bool Automatisch
		{
			get { return _automatisch; }
			set { _automatisch = value; }
		}


        [Description("Stop-Limit-Order")]
        [Category("Parameters")]
        public bool StopLimit
        {
            get { return _stopLimit; }
            set { _stopLimit = value; }
        }

        [Description("SendMail")]
        [Category("Strategy")]

        public bool SendMail
        {
            get { return _sendMail; }
            set { _sendMail = value; }
        }
        #endregion
	}
}
