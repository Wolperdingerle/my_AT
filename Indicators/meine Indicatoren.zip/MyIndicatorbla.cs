using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
	[Description("Enter the description for the new custom indicator here")]
	public class MyIndicatorbla : UserIndicator
    {
        public double Var1 = 105.0;
        public double Var2 = 106.0;

        
	
		protected override void Initialize()
		{
			Add(new Plot(Color.FromKnownColor(KnownColor.Orange), "MyPlot1"));
			Add(new Plot(Color.FromKnownColor(KnownColor.Green), "Plot2"));
			Overlay = true;
			CalculateOnBarClose = true;
		}

		protected override void OnBarUpdate()
		{
			MyPlot1.Set(Var1);
			Plot2.Set(Var2);
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries MyPlot1
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Plot2
		{
			get { return Values[1]; }
		}

		#endregion
	}
}
#region AgenaTrader Automaticaly Generated Code. Do not change it manualy

namespace AgenaTrader.UserCode
{
	#region Indicator

	public partial class UserIndicator
	{
		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla()
        {
			return MyIndicatorbla(Input);
		}

		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla(IDataSeries input)
		{
			var indicator = CachedCalculationUnits.GetCachedIndicator<MyIndicatorbla>(input);

			if (indicator != null)
				return indicator;

			indicator = new MyIndicatorbla
						{
							BarsRequired = BarsRequired,
							CalculateOnBarClose = CalculateOnBarClose,
							Input = input
						};
			indicator.SetUp();

			CachedCalculationUnits.AddIndicator2Cache(indicator);

			return indicator;
		}
	}

	#endregion

	#region Strategy

	public partial class UserStrategy
	{
		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla()
		{
			return LeadIndicator.MyIndicatorbla(Input);
		}

		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla(IDataSeries input)
		{
			if (InInitialize && input == null)
				throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

			return LeadIndicator.MyIndicatorbla(input);
		}
	}

	#endregion

	#region Column

	public partial class UserColumn
	{
		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla()
		{
			return LeadIndicator.MyIndicatorbla(Input);
		}

		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla(IDataSeries input)
		{
			return LeadIndicator.MyIndicatorbla(input);
		}
	}

	#endregion

	#region Scripted Condition

	public partial class UserScriptedCondition
	{
		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla()
		{
			return LeadIndicator.MyIndicatorbla(Input);
		}

		/// <summary>
		/// Enter the description for the new custom indicator here
		/// </summary>
		public MyIndicatorbla MyIndicatorbla(IDataSeries input)
		{
			return LeadIndicator.MyIndicatorbla(input);
		}
	}

	#endregion

}

#endregion
