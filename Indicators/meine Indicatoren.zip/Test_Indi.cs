using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
    public class ResultValue_Test_Indi
    {
        public bool ErrorOccured = false;
        public OrderAction? Entry = null;
        public OrderAction? Exit = null;
        public double Price = 0.0;
        public double Soft = 0.0;
        public double Hard = 0.0;
    }


    /// <summary>
    /// In this method we do all the work and return the object with all data like the OrderActions.
    /// This method can be called from any other script like strategies, indicators or conditions.
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    ///
    /*
    public ResultValue_Test_Indi calculate(IDataSeries data, int Abstand, int Toleranz, bool islongenabled, bool isshortenabled)
    {
        //Create a return object
        ResultValue_Test_Indi returnvalue = new ResultValue_Test_Indi();

        //try catch block with all calculations
        try
        {
            //Calculate SMA and set the data into the result object
            returnvalue.Soft = data.Low[0];
            returnvalue.Hard = High[0];
            returnvalue.Price = Last();

            /*
             * CrossAbove: We create buy (entry) signal for the long position and BuyToCover (exit) for the short position.
             * CrossBelow: We create sell (exit) signal for the long positon and SellShort (entry) for the short position.
             */
             /*
            if (CrossAbove(SMA(data, fastsma), SMA(data, slowsma), 0) == true)
            {
                if (islongenabled)
                {
                    returnvalue.Entry = OrderAction.Buy;
                }
                if (isshortenabled)
                {
                    returnvalue.Exit = OrderAction.BuyToCover;
                }

            }
            else if (CrossBelow(SMA(data, fastsma), SMA(data, slowsma), 0) == true)
            {
                if (islongenabled)
                {
                    returnvalue.Exit = OrderAction.Sell;
                }
                if (isshortenabled)
                {
                    returnvalue.Entry = OrderAction.SellShort;
                }
            }

        }
        catch (Exception)
        {
            //If this method is called via a strategy or a condition we need to log the error.
            returnvalue.ErrorOccured = true;
        }

        //return the result object
        return returnvalue;
    }

*/
    [Description("Testindicator")]
	public class Test_Indi : UserIndicator
	{
		#region Variables

		private int _abstand = 2;
		private int _toleranz = 2;
		private int _profit = 5;
        //      private int _trend = 2;
        private double Stopp = 0.0;
        
        private bool HardStopp_aktiv = false;
        private double Gewinn = 0.00;
        //input PlotColor
        private Color _plot0color = Color.Blue;
        private int _plot0width = 2;
        private DashStyle _plot0dashstyle = DashStyle.DashDotDot;
        private Color _plot1color = Color.Red;
        private int _plot1width = 2;
        private DashStyle _plot1dashstyle = DashStyle.Solid;

        #endregion

        protected override void Initialize()
		{
      
            //Define the plots and its color which is displayed underneath the chart
     //       Add(new Plot(this.Plot0Color, "Soft-Stopp"));
     //       Add(new Plot(this.Plot1Color, "Hard-Stopp"));

            Overlay = true;
			CalculateOnBarClose = true;
            BarsRequired = 2;
		}

		protected override void OnBarUpdate()
		{

            //Check if peridocity is valid for this script
            if (!DatafeedPeriodicityIsValid(Bars.TimeFrame))
            {
                Log(this.DisplayName + ": Periodicity of your data feed is suboptimal for this indicator!", InfoLogLevel.AlertLog);
                return;
            }

            if (TradeInfo == null || (TradeInfo.CreatedDateTime) >= Time[0]) return;  // Indikator bis Beginn des Trades nachzeichnen

            if (TradeInfo != null && TradeInfo.Quantity != 0)                         // solange der Trade l�uft
            {
                Gewinn = ((SoftStopp[1] - TradeInfo.AvgPrice) / TradeInfo.AvgPrice * 1000);

                if (InsideBarsMT(Input, InsideBarsMTToleranceUnit.Ticks, _toleranz).IsInsideBar[0] == 1.0)
                {
                    Stopp = Instrument.Round2TickSize(InsideBarsMT(Input, InsideBarsMTToleranceUnit.Ticks, _toleranz).LowBeforeOutsideBar[0] - _abstand * TickSize);
                    if (HardStopp_aktiv && HardStopp[1] > Stopp && Gewinn > _profit)
                        HardStopp[1] = Stopp;
                    else
                        // HardStopp[2] = HardStopp[3];
                        HardStopp[1] = HardStopp[2];
                }
                else
                {
                    Stopp = Instrument.Round2TickSize(Math.Max(Stopp, (Low[0] - _abstand * TickSize)));
                }
                SoftStopp[0] = Stopp;
                if (!HardStopp_aktiv && Gewinn > _profit && InsideBarsMT(Input, InsideBarsMTToleranceUnit.Ticks, _toleranz).IsInsideBar[0] < 1.0)    // Hardstopp erstmalig setzen
                {
                    HardStopp[0] = SoftStopp[0];
                    HardStopp_aktiv = true;
                }
                else if (HardStopp_aktiv && Close[1] < SoftStopp[1] && HardStopp[1] < SoftStopp[1])    // Hardstop nachziehen wenn alter Hardstopp kleiner
                {
                    HardStopp[0] = SoftStopp[1];
                }
                else if (HardStopp[1] > 0)      // Hardstopp beigehalten
                {
                    HardStopp[0] = HardStopp[1];
                }
                if (SoftStopp[1] > 0)
                    DrawTextFixed("MyText",
                    "Soft-Risk:  " + ((SoftStopp[1] - TradeInfo.AvgPrice) * TradeInfo.Quantity).ToString("F2") + " � ",
                    TextPosition.BottomLeft, Color.Blue, new Font("Areal", 12), Color.Blue, Color.Empty, 10);

                if (HardStopp[1] > 0)
                    DrawTextFixed("MyText1",
                    "Hard-Risk: " + ((HardStopp[1] - TradeInfo.AvgPrice) * TradeInfo.Quantity).ToString("F2") + " � ",
                    TextPosition.BottomLeft, Color.Blue, new Font("Areal", 12), Color.Blue, Color.Empty, 10);
            }

            else    // Trade ist geschlossen
            {
                if (TradeInfo != null && TradeInfo.Quantity == 0)
                {
                    SoftStopp.Reset();
                    HardStopp.Reset();
                }
                //Print();
            }
            //Set the drawing style, if the user has changed it.
            //Set the drawing style, if the user has changed it.
     

        }   // Ende on Bar Update ------------------------



        /// <summary>
        /// True if the periodicity of the data feed is correct for this indicator.
        /// </summary>
        /// <returns></returns>
        public bool DatafeedPeriodicityIsValid(ITimeFrame timeframe)
        {
            TimeFrame tf = (TimeFrame)timeframe;
            if (tf.Periodicity == DatafeedHistoryPeriodicity.Day || tf.Periodicity == DatafeedHistoryPeriodicity.Hour || tf.Periodicity == DatafeedHistoryPeriodicity.Minute)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #region Properties

        [Browsable(false)]
		[XmlIgnore()]
		public DataSeries SoftStopp
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries HardStopp
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Preis
		{
			get { return Values[2]; }
		}

		[Description("")]
		[Category("Parameters")]
		public int Abstand
		{
			get { return _abstand; }
			set { _abstand = Math.Max(0, value); }
		}

		[Description("")]
		[Category("Parameters")]
		public int Toleranz
		{
			get { return _toleranz; }
			set { _toleranz = Math.Max(0, value); }
		}

		[Description("")]
		[Category("Parameters")]
		public int Profit
		{
			get { return _profit; }
			set { _profit = Math.Max(0, value); }
		}


        /// <summary>
        /// </summary>
        [Description("W�hle Farbe f�r Hard-Stopp.")]
        [Category("Plots")]
        [DisplayName("Color Hard-Stopp")]
        public Color Plot1Color
        {
            get { return _plot1color; }
            set { _plot1color = value; }
        }
        // Serialize Color object
        [Browsable(false)]
        public string Plot1ColorSerialize
        {
            get { return SerializableColor.ToString(_plot1color); }
            set { _plot1color = SerializableColor.FromString(value); }
        }

        /// <summary>
        /// </summary>
        [Description("Linienbreite f�r Hard-Stopp.")]
        [Category("Plots")]
        [DisplayName("Linienbreite f�r Hard-Stopp")]
        public int Plot1Width
        {
            get { return _plot1width; }
            set { _plot1width = Math.Max(1, value); }
        }

        /// <summary>
        /// </summary>
        [Description("DashStyle f�r Hard-Stopp.")]
        [Category("Plots")]
        [DisplayName("DashStyle Hard-Stopp")]
        public DashStyle Dash1Style
        {
            get { return _plot1dashstyle; }
            set { _plot1dashstyle = value; }
        }

        #endregion
    }
}
#region AgenaTrader Automaticaly Generated Code. Do not change it manualy

namespace AgenaTrader.UserCode
{
	#region Indicator

	public partial class UserIndicator
	{
		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
        {
			return Test_Indi(Input, abstand, toleranz, profit);
		}

		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(IDataSeries input, System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
		{
			var indicator = CachedCalculationUnits.GetCachedIndicator<Test_Indi>(input, i => i.Abstand == abstand && i.Toleranz == toleranz && i.Profit == profit);

			if (indicator != null)
				return indicator;

			indicator = new Test_Indi
						{
							BarsRequired = BarsRequired,
							CalculateOnBarClose = CalculateOnBarClose,
							Input = input,
							Abstand = abstand,
							Toleranz = toleranz,
							Profit = profit
						};
			indicator.SetUp();

			CachedCalculationUnits.AddIndicator2Cache(indicator);

			return indicator;
		}
	}

	#endregion

	#region Strategy

	public partial class UserStrategy
	{
		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
		{
			return LeadIndicator.Test_Indi(Input, abstand, toleranz, profit);
		}

		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(IDataSeries input, System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
		{
			if (InInitialize && input == null)
				throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

			return LeadIndicator.Test_Indi(input, abstand, toleranz, profit);
		}
	}

	#endregion

	#region Column

	public partial class UserColumn
	{
		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
		{
			return LeadIndicator.Test_Indi(Input, abstand, toleranz, profit);
		}

		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(IDataSeries input, System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
		{
			return LeadIndicator.Test_Indi(input, abstand, toleranz, profit);
		}
	}

	#endregion

	#region Scripted Condition

	public partial class UserScriptedCondition
	{
		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
		{
			return LeadIndicator.Test_Indi(Input, abstand, toleranz, profit);
		}

		/// <summary>
		/// Testindicator
		/// </summary>
		public Test_Indi Test_Indi(IDataSeries input, System.Int32 abstand, System.Int32 toleranz, System.Int32 profit)
		{
			return LeadIndicator.Test_Indi(input, abstand, toleranz, profit);
		}
	}

	#endregion

}

#endregion
