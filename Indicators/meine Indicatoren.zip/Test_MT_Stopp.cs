using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
	[Description("Testindikator MT-Bewegungsstopp")]
	public class Test_MT_Stopp : UserIndicator
	{
        private double Stopp = 0.0;
        protected override void Initialize()
		{
			Add(new Plot(Color.FromKnownColor(KnownColor.Green), "Soft-Stopp"));
            Overlay = true;
			CalculateOnBarClose = false;
		}

		protected override void OnBarUpdate()
		{
            
            if (InsideBarsMT().IsInsideBar[0] == 1.0)
            {
                Plots[0].Pen.Width = 3;
                Stopp = Instrument.Round2TickSize(InsideBarsMT().LowBeforeOutsideBar[0]);
            }
            else
            {
                Plots[0].Pen.Width = 1;
                Stopp = Instrument.Round2TickSize(Math.Max(Stopp, Low[1]));
            }
            if (Close[1] < Stopp)
            {
                Stopp = Instrument.Round2TickSize(Math.Max(Low[1], Low[0]));
            }
            Soft_Stopp.Set(Stopp);
           // MyPlot2.Set(Stopp-0.5);

        }

		#region Properties

		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Soft_Stopp
        {
			get { return Values[0]; }
		}
        [Browsable(false)]
        [XmlIgnore()]
        public DataSeries MyPlot2
        {
            get { return Values[1]; }
        }
        #endregion
    }
}
#region AgenaTrader Automaticaly Generated Code. Do not change it manualy

namespace AgenaTrader.UserCode
{
	#region Indicator

	public partial class UserIndicator
	{
		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp()
        {
			return Test_MT_Stopp(Input);
		}

		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp(IDataSeries input)
		{
			var indicator = CachedCalculationUnits.GetCachedIndicator<Test_MT_Stopp>(input);

			if (indicator != null)
				return indicator;

			indicator = new Test_MT_Stopp
						{
							BarsRequired = BarsRequired,
							CalculateOnBarClose = CalculateOnBarClose,
							Input = input
						};
			indicator.SetUp();

			CachedCalculationUnits.AddIndicator2Cache(indicator);

			return indicator;
		}
	}

	#endregion

	#region Strategy

	public partial class UserStrategy
	{
		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp()
		{
			return LeadIndicator.Test_MT_Stopp(Input);
		}

		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp(IDataSeries input)
		{
			if (InInitialize && input == null)
				throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

			return LeadIndicator.Test_MT_Stopp(input);
		}
	}

	#endregion

	#region Column

	public partial class UserColumn
	{
		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp()
		{
			return LeadIndicator.Test_MT_Stopp(Input);
		}

		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp(IDataSeries input)
		{
			return LeadIndicator.Test_MT_Stopp(input);
		}
	}

	#endregion

	#region Scripted Condition

	public partial class UserScriptedCondition
	{
		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp()
		{
			return LeadIndicator.Test_MT_Stopp(Input);
		}

		/// <summary>
		/// Testindikator MT-Bewegungsstopp
		/// </summary>
		public Test_MT_Stopp Test_MT_Stopp(IDataSeries input)
		{
			return LeadIndicator.Test_MT_Stopp(input);
		}
	}

	#endregion

}

#endregion
