using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using AgenaTrader.API;
using AgenaTrader.Custom;
using AgenaTrader.Plugins;
using AgenaTrader.Helper;

namespace AgenaTrader.UserCode
{
	[Description("Durchschnittlicher, täglicher Marktumsatz")]
	public class MarktUmsatz : UserIndicator
	{
        #region Variables

        private int _period = 14;
       

        #endregion      
           public MarktUmsatz()
        {
            
            BarsRequired = _period;
            Overlay = true;
        }
		protected override void Initialize()
		{
			Add(new Plot(Color.FromKnownColor(KnownColor.Orange), "Umsatz"));
			CalculateOnBarClose = true;
            
		}

		protected override void OnBarUpdate()
		{
           
			Umsatz.Set(SMA(Volume, _period)[0] * SMA(Close, _period)[0]/1000);

		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Umsatz
		{
			get { return Values[0]; }
		}

		#endregion
	}
}
#region AgenaTrader Automaticaly Generated Code. Do not change it manualy

namespace AgenaTrader.UserCode
{
	#region Indicator

	public partial class UserIndicator
	{
		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz()
        {
			return MarktUmsatz(Input);
		}

		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz(IDataSeries input)
		{
			var indicator = CachedCalculationUnits.GetCachedIndicator<MarktUmsatz>(input);

			if (indicator != null)
				return indicator;

			indicator = new MarktUmsatz
						{
							BarsRequired = BarsRequired,
							CalculateOnBarClose = CalculateOnBarClose,
							Input = input
						};
			indicator.SetUp();

			CachedCalculationUnits.AddIndicator2Cache(indicator);

			return indicator;
		}
	}

	#endregion

	#region Strategy

	public partial class UserStrategy
	{
		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz()
		{
			return LeadIndicator.MarktUmsatz(Input);
		}

		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz(IDataSeries input)
		{
			if (InInitialize && input == null)
				throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

			return LeadIndicator.MarktUmsatz(input);
		}
	}

	#endregion

	#region Column

	public partial class UserColumn
	{
		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz()
		{
			return LeadIndicator.MarktUmsatz(Input);
		}

		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz(IDataSeries input)
		{
			return LeadIndicator.MarktUmsatz(input);
		}
	}

	#endregion

	#region Scripted Condition

	public partial class UserScriptedCondition
	{
		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz()
		{
			return LeadIndicator.MarktUmsatz(Input);
		}

		/// <summary>
		/// Durchschnittlicher, täglicher Marktumsatz
		/// </summary>
		public MarktUmsatz MarktUmsatz(IDataSeries input)
		{
			return LeadIndicator.MarktUmsatz(input);
		}
	}

	#endregion

}

#endregion
